iot-raspberrypi
===============
This repository contains working sample device client software for the IBM Internet of Things Cloud service
on the Raspberry Pi model B.

Raspberry Pi
============

See this [recipe](https://www.ibmdw.net/iot/recipes/raspberry-pi/) for running the code in this repository.


Content
=======
There is a C sample that installs an 'iot' service, which you can use to connect to and interact with QuickStart or a registered organization in the Internet of Things Cloud. For more details, refer to the README in samples/c.

